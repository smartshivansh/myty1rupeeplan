const express = require("express");
const Router = express.Router();

// Router.get("/:id", (req, res) => {
//   res.status(200).send({
//     id: req.params.id,
//   });
// });

module.exports = Router;
