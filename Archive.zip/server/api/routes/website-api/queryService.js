async function lookupUser() {}

async function findPosts() {}
