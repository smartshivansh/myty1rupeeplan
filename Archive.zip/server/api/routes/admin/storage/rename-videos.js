const express = require("express");
const Router = express.Router();

Router.patch("/", async (req, res) => {
  try {
  } catch (error) {}
});

module.exports = Router;
