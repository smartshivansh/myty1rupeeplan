const { default: axios } = require('axios');
const express = require('express');
const Search = require('../../../models/Search');
const {
  queryCollection,
  queryImageCollection,
  queryMultiCollection,
  queryMultiCollectionForSuggestion,
  createBlogCollection,
  createImageCollection,
  createVideoCollection,
  createQuoteCollection,
  deleteCollection,
  retrive,
} = require('../../../utils/typesense/actions');

const router = express.Router();

router.post('/', async (req, res) => {
  const isHostMytym = hostIsMytym(req.hostname);
  try {
    if (!isHostMytym) {
      console.log('requesting for data to mytym search server ME');
      const response = await axios.post('https://mytym.in/api/search', req.body);
      res.status(200).send(response.data);
      return;
    } else {
      const { query } = req.body;
      queryMultiCollection(query)
        .then((results) => {
          if (results.results.blog.length > 0) {
            res.status(200).send(results);
          }
          // else {
          //   queryMultiCollection(query, true)
          //     .then((results) => {
          //       res.status(200).send(results);
          //     })
          //     .catch((error) => {
          //       console.log(error);
          //     });
          // }
        })
        .catch((error) => {
          // console.log(error);
          console.log('ERROR at LOCATION .catch in search');
        });
    }
  } catch (e) {
    console.log('error in saving search query', e);
    res.status(405).send(e);
  }
});

router.post('/suggestion', async (req, res) => {
  const { query } = req.body;
  console.log('query for search', query);

  try {
    const searchQuery = new Search({
      query,
    });
    searchQuery.save();
  } catch (e) {
    console.log('error in saving search query', e);
  }

  const isHostMytym = hostIsMytym(req.hostname);
  if (!isHostMytym) {
    console.log('requesting for data to mytym search server');
    const response = await axios.post(
      'https://mytym.in/api/search/suggestion',
      req.body
    );
    res.status(200).send(response.data);
    return;
  }

  queryMultiCollectionForSuggestion(query)
    .then((results) => {
      if (results.results.length > 0) {
        res.status(200).send(results);
      } else {
        queryMultiCollectionForSuggestion(query, true)
          .then((results) => {
            res.status(200).send(results);
          })
          .catch((error) => {
            console.log(error);
          });
      }
    })
    .catch((error) => {
      console.log(error);
    });
});

router.get('/createCollections', async (req, res) => {
  try {
    // deleteCollection("image");
    // deleteCollection("blogs");
    // deleteCollection("video");
    // deleteCollection("quote");

    createBlogCollection();
    createImageCollection();
    createQuoteCollection();
    createVideoCollection();
  } catch (error) {
    console.log('error', error);
  }

  // setTimeout(async () => {
  //   retrive("all");
  // }, 8000);

  res.send(200);
});

router.get('/listCollections', async (req, res) => {
  res.send(await retrive());
});

router.get('/deleteCollections', async (req, res) => {
  try {
    deleteCollection('image');
    deleteCollection('blogs');
    deleteCollection('video');
    deleteCollection('quote');
  } catch (error) {
    console.log('error', error);
  }

  res.sendStatus(200);
});

module.exports = router;

// Utils
function hostIsMytym(hostname) {
  console.log('\nHOSTNAME', hostname);
  if (hostname === 'mytym.in' || hostname === 'www.mytym.in') {
    return true;
  }

  console.log('is not mytym');
  return false;
}
