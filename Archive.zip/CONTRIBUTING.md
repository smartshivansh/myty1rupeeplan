# Contribution Guide
1. Please add comments - AJ - for future developers to work smoothly.
2. Use standard variable names with some convention like camel cases
